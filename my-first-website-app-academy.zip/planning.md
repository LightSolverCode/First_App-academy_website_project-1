First page:

1. Background-color: black;
2. name {font: Arsenica}
3. h1 font: Arimo
4. Nav: at the top - ul element with flexbox


Second page:

1. background-color: white;
2. h1 Arimo:
3. two images one with css rotation.
4. p tag = short description of self. <article>

third page:

1. h1: work experiance
2. background-color: white;
3. Two divs with Ul elents inside a container div <div>

forth page: 

1. background-color: white;
2. Two divs with Ul elents inside a container div <div>

fith page:

1. three divs with img elements and labels for each img underneath

forth page: 

1. black background
2. h1 throughout. fist and third h1 font = Arimo, second h1 font =  Arsenica.


fith page/ footer page:

1. h1 tag
2. bg color white
3. <Article> with 3 h3 tags 
4. image with css rotation
